HYDERABAD SPICE HOUSE — AI WEBSITE DEMO

Files:
- index.html
- style.css
- script.js

How to view:
1. Keep all three files in the same folder.
2. Open index.html in Chrome.

Important:
- This is a fictional portfolio demo.
- Replace the WhatsApp number, address, dishes, prices and images before using it for a real customer.
- The demo uses Unsplash image URLs, so an internet connection is needed for the photos/fonts.

Next business step:
Use this as your portfolio sample and offer customized restaurant websites to local businesses.
